<?php
session_start();
if(!isset($_SESSION['sess_user']))
{
	header("location:loginpage.php");
}
else
{
?>

<html>
<body>
<script>
function goBack() {
    window.history.back();
}
</script>
<?php

$connect=mysqli_connect("localhost","root","","bookstore");
$name=$_SESSION['sess_user'];

$query=$connect->prepare("SELECT address FROM users where username='$name'");
$query->execute();
$query->bind_result($encrypted_address);

while($query->fetch())
{
	
	
	$key = "sufbmxhemynftbix";
	$iv = "aczuhfcktsixendv";
	$decoded = base64_decode($encrypted_address);
	$original_address = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $key, $decoded, MCRYPT_MODE_CFB, $iv);
	echo "<center><h1>" .$original_address. "</h1></center>";
	
	
}




?>
<center><a href="javascript:goBack()">Back</a></center>
</body>
</html>

<?php
}
?>
