<html>
<body>
<script>
function goBack() {
    window.history.back();
}
</script>
<a href="javascript:goBack()">Back</a>
<center>
<h1>Checkout</h1>

<p>Please key in your address and email to confirm purchase:

<table align="center" border="0">
<tr>
<form method="post" action="buy.php">
<td><input type="text" name="title" value="please input title of the book" ></td>
<td><input type="text" name="address" value="please input address" ></td>
<td><input type="varchar" name="email" value="example@email.com" ></td>
<td><input type="submit" value="Purchase" name="purchase"></td>
</form>
</tr>

</p>
</center>


</body>
<?php
if(isset($_POST["purchase"]))
{
	if(!empty($_POST['email']))
	{
		$bookname= $_POST['title'];
		$email = $_POST['email'];
		$address = $_POST['address'];
	
		//DB Connection
		$conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
		//Select DB From database
		$db = mysqli_select_db($conn, 'bookstore') or die("database error");
		//Selecting database
		$query = mysqli_query($conn, "SELECT address,email FROM users WHERE email='".$email."'");
		$numrows = mysqli_num_rows($query);
		if($numrows >0)
		{
			while($row = mysqli_fetch_assoc($query))
			{
				$dbaddress=$row['address'];
				$dbemail=$row['email'];
				$unhashed=password_verify($address, $dbaddress);
			}
			if($email == $dbemail)
			{
				
				echo "<h3>You have successfully purchased the book with the title '".$bookname."'. Payment is cash on delivery and it will arrive in 3 working days.</h3>";
				echo "<h3>The parcel will be delivered to the following address: '".$address."'</h3>";
				
				
				
			}
		}
		else
		{
			echo "Please try again!";
		}
	}
	else
	{
		echo "Required All fields!";
	}
}



if(isset($_POST["purchase"]))
{
	if(!empty($_POST['email']))
	{
		$connect=mysqli_connect("localhost","root","","bookstore");

		$query=$connect->prepare("select * from stocks where title='".$bookname."'");
		$query->execute();
		$query->bind_result($supplier, $supplier_id, $serialNum, $title, $wholesaleValue, $retailValue, $quantityInStock, $stockValue);
		while($query->fetch())
		{
			
		}
		
		$amount=1;
		
		$query2=$connect->prepare("UPDATE stocks SET quantityInStock = (quantityInStock - ".$amount.") where title='".$title."';");
		$query2->execute();
		
		
	}
}
?>
</html>