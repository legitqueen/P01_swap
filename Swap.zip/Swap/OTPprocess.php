<?php
session_start();
if(!isset($_SESSION['otp'])&&!isset($_SESSION['sess_user']))
{
	header("location:loginpage.php");
}

else
{
?>

<html>
<body>

<?php

if(isset($_POST["submit"]))
	{
		if(!empty($_POST['otp']))
		{
			$otp = $_POST['otp'];
			
			if ($otp==$_SESSION['otp'])
			{
				$conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
				//Select DB From database
				$db = mysqli_select_db($conn, 'bookstore') or die("database error");
				//Selecting database
				$query = mysqli_query($conn, "SELECT id FROM users WHERE username='".$_SESSION['sess_user']."'");
				$numrows = mysqli_num_rows($query);
				if($numrows >0)
				{
					while($row = mysqli_fetch_assoc($query))
					{
						$dbid=$row['id'];
						
					}
					
					if($dbid == '1')
					{		
						
						
						header("Location:stockInfo.php");
					}
					else
					{
						
						header("Location: MainPage.php");
					}
					
				}
			}
			else
			{
				echo"Wrong OTP";
			}
		}
		else
		{
			echo"Please type in your OTP";
		}
	}			
?>
<form action="OTPprocess.php" method="post" >
<table align='center' border=0>
<tr>
<td>Please enter your OTP: </td>
<td><input type=int name="otp" required></td>
<td><input type="submit" value="Confirm" name="submit"</td>
</tr>
</form>
</body>
</html>
<?php
}
?>