<?php
session_start();
if(!isset($_SESSION['sess_user']))
{
	header("location:loginpage.php");
}
else
{
?>
<?php
$name=$_SESSION['sess_user'];

if(isset($_POST["change"])){
	if($_POST["change"]=="yes")
	{
		
		
		if(!empty($_POST['oldpass']) && !empty($_POST['newpass']) && !empty($_POST['newpass2']))
		{
			$oldpass=$_POST["oldpass"];
			$newpass=$_POST["newpass"];
			$newpass2=$_POST["newpass2"];
		
			//DB Connection
			$conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
			//Select DB From database
			$db = mysqli_select_db($conn, 'bookstore') or die("database error");
			//Selecting database
			$query = mysqli_query($conn, "SELECT password FROM users WHERE username='$name'");
			$numrows = mysqli_num_rows($query);
			
			if($numrows >0)
			{
				while($row = mysqli_fetch_assoc($query))
				{
					$dbpassword=$row['password'];
					$unhashed=password_verify($oldpass, $dbpassword);
					if ($oldpass=$unhashed)
					{
						if ($newpass=$newpass2)
						{
							$options = ['cost' => 12];
							$md5= password_hash($newpass2, PASSWORD_DEFAULT, $options);
							$query2=$conn->prepare("UPDATE `users` SET `password` = '$md5' WHERE username='$name';");
							if($query2->execute())
							{
								echo "Successfully changed password!";
							}
						}
						else
						{
							echo "Passwords do not match!";
						}
					}
					else
					{
						echo "Old password does not match!";
					}
				}
			}
		}	
	}
}




?>
<html>
<body>

<center><h1>Change your password</h1></center>
<a href="userinfo.php">Back</a>
<form method="post" action="changepassword.php">
<table align="center" border="0">
<tr>
<td>Old password:</td>
<td><input type="password" name="oldpass" required /></td>
</tr>
<tr>
<td>New password:</td>
<td><input type="password" min="1" name="newpass" required /></td>
</tr>
<tr>
<td>Retype new password:</td>
<td><input type="password" min="1" name="newpass2" required /></td>
</tr>

<tr>
<td>&nbsp;</td>
<td align="right">
<input type="hidden" name="change" value="yes" />
<input type="submit" value="Change"/></td>
</tr>
</form>

</body>
</html>
<?php
}
?>
