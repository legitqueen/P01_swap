<?php
session_start();
if(!isset($_SESSION['sess_user']))
{
	header("location:loginpage.php");
}
else
{
?>
<html>
<body>

<h1 align="center">Welcome <?=$_SESSION['sess_user'];?>!</right></h1>
<h2 align="center">Edit your info</h1>
<a href="MainPage.php">Back</a>

<?php

$connect=mysqli_connect("localhost","root","","bookstore");

$name=$_SESSION['sess_user'];

$query=$connect->prepare("SELECT username,first_name,last_name,address,email,password FROM users where username='$name'");
$query->execute();
$query->bind_result($username, $first_name, $last_name, $encrypted_address, $email, $hashed_password);
echo "<table cellpadding='15' align='center' border='1'>";
echo "<tr>";
echo "<th>Username</th>";
echo "<th>First name</th>";
echo "<th>Last name</th>";
echo "<th>Address</th>";
echo "<th>Email</th>";
echo "<th>Password</th>";


echo "</tr>";
while($query->fetch())
{
	
	echo "<tr>";
	echo "<td>".$username."</td>";
	echo "<td>".$first_name."</td>";
	echo "<td>".$last_name."</td>";
	echo "<td>".$encrypted_address."</td>";
	echo "<td>".$email."</td>";
	echo "<td>".$hashed_password."</td>";
	
	
	
	
	
	echo "</tr>";
	
	
}
echo "</table>";
echo "<br>";
echo "<center><a href='decrypt.php'><button>Show Address</button></a></center>";
echo "<br>";
echo "<center><a href='changepassword.php'><button>Change Password</button></a></center>";
?>

</body>
</html>
<?php
}
?>