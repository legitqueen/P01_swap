<html>
<head>
<script>
var allowSubmit =false;

var onloadCallback = function() {
    grecaptcha.render('g-recaptcha', {
      'sitekey' : '6LeNaEUUAAAAAPTp3gRlJvDnbYzNb8fXzwO0c3KV',
      'callback': capcha_filled,
      'expired-callback': capcha_expired,
    });
  };

function capcha_filled()
{
	allowSubmit = true;
}

function capcha_expired()
{
	allowSubmit = false;
}

function check_if_capcha_is_filled (e)
{
	if(allowSubmit) return true;
	e.preventDefault();
	alert('Fill in the capcha!);
}
</script>
<script src='https://www.google.com/recaptcha/api.js'></script>
<link rel="stylesheet" href="signupstyle.css">
<title>Login</title>
</head>
<body>
<h1><center>Login</center></h1>
<form action="" method="post" >
<label>Username:</label><input type="text" name="username"><br/>
<label>Password:</label><input type="password" name="password"><br/>
<div class="g-recaptcha" 
	data-callback="capcha_filled"
	data-expired-callback="capcha_expired"
	data-sitekey="6LeNaEUUAAAAAPTp3gRlJvDnbYzNb8fXzwO0c3KV"></div>
<input type="submit" value="Login" name="submit" onclick="check_if_capcha_is_filled"><br/>
<!--New user Register Link -->
<p><a href="signup.php">New User Registeration!</a></p>
</form>
<?php

date_default_timezone_set( 'Asia/Singapore' ) ;
$date = date('Y-m-d H:i:s');


if ((date ("G") >= 9) && (date ("G") <= 19)) //change this as necessary
{
	if(isset($_POST["submit"]))
	{
		if(!empty($_POST['username']) && !empty($_POST['password']))
		{
			$username = $_POST['username'];
			$password = $_POST['password'];
		
			//DB Connection
			$conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
			//Select DB From database
			$db = mysqli_select_db($conn, 'bookstore') or die("database error");
			//Selecting database
			$query = mysqli_query($conn, "SELECT username,password,id FROM users WHERE username='".$username."'");
			$numrows = mysqli_num_rows($query);
			if($numrows >0)
			{
				while($row = mysqli_fetch_assoc($query))
				{
					$dbusername=$row['username'];
					$dbpassword=$row['password'];
					$dbid=$row['id'];
					$unhashed=password_verify($password, $dbpassword);
				}
				if($username == $dbusername && $password == $unhashed)
				{
					
						$logevent = "$username has logged in.";
						$sql = "INSERT INTO log (date, user, event )VALUES ('$date', '$username', '$logevent');"; 
						$result = mysqli_query($conn,$sql);
											
						$OTP=rand(1000, 9999);
						
						$message = "This is your OTP: $OTP";
						$connect=mysqli_connect("localhost","root","","bookstore");

						$query=$connect->prepare("SELECT email FROM users WHERE username='".$username."'");
						$query->execute();
						$query->bind_result($email);
						while ($query->fetch())
						{
							$e=$email;
						}
						$log++;
						if(mail(''.$e.'', 'This is your One Time Password', ''.$message.'', 'From: bhone.htetkyaw@gmail.com') == true);
						{
		
							session_start();
							
							$_SESSION['otp']=$OTP;
							$_SESSION['sess_user']=$username;
							//Redirect Browser
							header("Location:OTPprocess.php");
						}
						
				
				}
			}	
			else
			{
				$log=0;
				if ($log==0)
				{
					$logevent = "Invalid Username or Password.";
					$sql = "INSERT INTO log (date, user, event )VALUES ('$date', '$username', '$logevent');"; 
					$result = mysqli_query($conn,$sql);
					$log++;
					echo "Invalid Username or Password!";
				}
				
				
				
			}
		}
		else
		{
			
			
			$conn = mysqli_connect('localhost', 'root', '', 'bookstore');
			if(mysqli_error($conn))
			{
				die('Connection fail: '. mysqli_error($conn));
			}
			$log=0;
			$username = $_POST['username'];
			if ($log == 0)
			{
				$logevent = "No username or password entered.";
				$sql = "INSERT INTO log (date, user, event )VALUES ('$date', '$username', '$logevent');";  
				$result = mysqli_query($conn,$sql);
				$log++;
				echo "Required All fields!";
			}
		
		}
	}	
}
else 
{
	die("Login only available from 9am - 7pm");
}
?>
</body>
</html>
