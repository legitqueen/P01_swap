<?php
	$key = openssl_random_pseudo_bytes(32);
	$cipher = "aes-128-gcm";
	$ivlen = openssl_cipher_iv_length($cipher);
	$iv = openssl_random_pseudo_bytes($ivlen);
	$tag = NULL;
?>