<?php

$OTP=rand(1000, 9999);
session_start();
$_SESSION['otp']=$OTP;
?>